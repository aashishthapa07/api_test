class ApiService {
  static const String baseUrl = 'https://qa-ravenapi.ekbana.net';
}
